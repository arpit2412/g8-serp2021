static void
_tiffDummyUnmapProc(thandle_t fd, tdata_t base, toff_t size)
{
}
