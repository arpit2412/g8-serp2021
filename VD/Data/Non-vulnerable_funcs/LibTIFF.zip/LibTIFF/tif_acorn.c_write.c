}
extern int write(int fd, const char *buf, int nbytes)
{
	/* Returns number of bytes written */
	return (nbytes - osgbpb_write((os_f) fd, (const byte*) buf, nbytes));
}
