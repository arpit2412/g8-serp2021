/* Dummy entry point for backwards compatibility */
void TIFFModeCCITTFax3(void){}
#endif
