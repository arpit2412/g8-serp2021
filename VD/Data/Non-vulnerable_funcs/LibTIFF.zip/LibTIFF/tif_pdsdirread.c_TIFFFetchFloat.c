static float
TIFFFetchFloat(TIFF* tif, TIFFDirEntry* dir)
{
	/* This appears to be a flagrant bug in the TIFF library, yet I
	   actually don't understand how it could have ever worked the old
	   way. Look at the comments in my new code and you'll understand. */
#if (0)
	float v = (float)
	    TIFFExtractData(tif, dir->tdir_type, dir->tdir_offset);
	TIFFCvtIEEEFloatToNative(tif, 1, &v);
#else
	float v;
	/* This is a little bit tricky - if we just cast the uint32 to a float,
	   C will perform a numerical conversion, which is not what we want.
	   We want to take the actual bit pattern in the uint32 and interpret
	   it as a float. Thus we cast a uint32 * into a float * and then
	   dereference to get v. */
	uint32 l = (uint32)
	    TIFFExtractData(tif, dir->tdir_type, dir->tdir_offset);
	v = * (float *) &l;
	TIFFCvtIEEEFloatToNative(tif, 1, &v);
#endif
	return (v);
}
