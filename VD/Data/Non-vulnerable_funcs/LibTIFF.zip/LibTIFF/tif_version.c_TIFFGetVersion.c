const char*
TIFFGetVersion(void)
{
	return (TIFFVersion);
}
