void
_TIFFfree(tdata_t p)
{
	GlobalFreePtr(p);
}
