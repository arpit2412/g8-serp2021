}
extern int read(int fd, char *buf, int nbytes)
{
	/* Returns number of bytes read */
	return (nbytes - osgbpb_read((os_f) fd, (byte*) buf, nbytes));
}
