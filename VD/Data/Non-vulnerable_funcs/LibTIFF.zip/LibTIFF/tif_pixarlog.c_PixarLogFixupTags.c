static int
PixarLogFixupTags(TIFF* tif)
{
	(void) tif;
	return (1);
}
