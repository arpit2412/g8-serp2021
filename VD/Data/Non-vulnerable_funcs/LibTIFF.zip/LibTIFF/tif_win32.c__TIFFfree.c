void
_TIFFfree(tdata_t p)
{
	GlobalFree(p);
	return;
}
