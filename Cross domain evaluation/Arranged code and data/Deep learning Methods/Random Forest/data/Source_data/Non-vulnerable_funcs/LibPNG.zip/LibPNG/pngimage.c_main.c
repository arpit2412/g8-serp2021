int
main(void)
{
   fprintf(stderr, "pngimage: no support for png_read/write_image\n");
   return 77;
}
