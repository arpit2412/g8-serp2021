static void
newimage(Image *image)
{
   memset(image, 0, sizeof *image);
}
