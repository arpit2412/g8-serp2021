static void
type_sep(FILE *out)
{
   putc(':', out);
   putc(' ', out);
}
