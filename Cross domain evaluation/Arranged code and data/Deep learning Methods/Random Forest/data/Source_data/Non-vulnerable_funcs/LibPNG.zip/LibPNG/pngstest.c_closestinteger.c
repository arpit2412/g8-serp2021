static double
closestinteger(double x)
{
   return floor(x + .5);
}
